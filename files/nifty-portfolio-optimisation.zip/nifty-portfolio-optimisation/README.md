# NIFTY Portfolio Optimisation, Risk & Walk-Forward Backtest

Mean-variance optimisation, CAPM, VaR/CVaR and an out-of-sample backtest on 12 Indian large caps + gold, built from scratch in Python (NumPy, pandas, SciPy, scikit-learn).

**Question:** does portfolio optimisation actually beat equal weighting and the NIFTY 50 once it is tested on data it has not seen, after costs?

## Headline result (out-of-sample, Nov-2021 → Nov-2026, quarterly rebalancing, 10 bp costs)

| Strategy | CAGR | Volatility | Sharpe | Max drawdown |
|---|---|---|---|---|
| **Max Sharpe** (≤25% per asset) | **16.9%** | 13.0% | **0.81** | −17.7% |
| Min variance | 13.4% | 10.8% | 0.67 | −15.4% |
| Risk parity | 12.6% | 10.8% | 0.61 | −14.9% |
| Equal weight | 11.4% | 12.1% | 0.47 | −17.4% |
| NIFTY 50 (price index) | 7.5% | 13.9% | 0.17 | −16.5% |

![Backtest](figures/05_backtest.png)

**Key insights**
- Max-Sharpe's edge survives removing gold from the universe (Sharpe 0.81 → 0.74); min-variance's does not (0.67 → 0.33) – it was really a gold-allocation strategy.
- Daily returns have fat tails (excess kurtosis ~15): normal-distribution VaR understates 99% CVaR by ~35%. Rolling historical VaR passes the Kupiec back-test.
- Only 1 of 13 assets shows statistically significant CAPM alpha.

Full analysis, limitations and robustness checks: **[NIFTY_Portfolio_Optimisation.ipynb](NIFTY_Portfolio_Optimisation.ipynb)**

![Efficient frontier](figures/02_efficient_frontier.png)

## What's inside
| Section | Methods |
|---|---|
| Data cleaning | Detects and repairs mis-scaled prints (GOLDBEES Dec-2019), calendar alignment |
| Exploratory | Annualised return/vol/Sharpe, correlation heatmap |
| Efficient frontier | 10,000 Dirichlet random portfolios; SLSQP frontier; max-Sharpe, min-variance, risk parity (convex ERC); Ledoit-Wolf covariance shrinkage |
| CAPM | OLS beta/alpha with t-stats, Security Market Line |
| Risk | Historical / parametric / Monte Carlo VaR & CVaR, rolling VaR back-test with Kupiec POF test, drawdowns |
| Backtest | Walk-forward (no look-ahead), drifting weights, turnover-based costs, Sharpe/Sortino/Calmar/IR, 9-setting robustness grid, ex-gold test |

## Repository
```
├── NIFTY_Portfolio_Optimisation.ipynb   # analysis with outputs
├── src/portfolio.py                     # reusable functions (optimisers, VaR, backtester)
├── data/prices_raw.csv                  # Yahoo Finance adjusted closes, Nov-2019 → Nov-2026
├── data/prices_clean.csv                # after cleaning
├── figures/                             # charts used in this README
├── get_data.py                          # re-downloads the data
└── requirements.txt
```

## Run it
```bash
pip install -r requirements.txt
jupyter notebook NIFTY_Portfolio_Optimisation.ipynb
```

## Limitations
Universe chosen with hindsight (today's large caps); NIFTY 50 is a price index while stocks are dividend-adjusted (index total return ≈ +1–1.5% p.a.); constant risk-free rate; simplified costs; no taxes; one ~5-year regime.

---
**Prathamesh Rathi** · BBA (Finance) · CFA Level II candidate · FMVA · [LinkedIn](https://linkedin.com/in/prathameshrathi7)
*Educational project – not investment advice.*
