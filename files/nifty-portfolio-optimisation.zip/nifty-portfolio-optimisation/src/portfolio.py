"""Portfolio optimisation, risk and backtesting toolkit (NumPy / pandas / SciPy)."""
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import norm, chi2
from sklearn.covariance import LedoitWolf

TD = 252  # trading days per year


# ---------------------------------------------------------------- data
def load_prices(path):
    """Load Yahoo close prices, fix known bad prints, align calendars."""
    px = pd.read_csv(path, parse_dates=["Date"], index_col="Date").sort_index()
    px = px.dropna(how="all")
    log = []
    # A price that is <2% of both neighbours is a mis-scaled print (e.g. quoted per 1/100 unit)
    for col in px.columns:
        s = px[col]
        ratio = s / s.rolling(11, center=True, min_periods=3).median()
        bad = ratio < 0.02
        if bad.any():
            log.append((col, list(s.index[bad].strftime("%d-%b-%Y")), list(s[bad].round(4))))
            px.loc[bad, col] = np.nan
    px = px.ffill().dropna()
    return px, log


def returns(px):
    return px.pct_change().dropna()


# ---------------------------------------------------------------- statistics
def ann_stats(r, rf=0.0):
    mu = r.mean() * TD
    vol = r.std() * np.sqrt(TD)
    cagr = (1 + r).prod() ** (TD / len(r)) - 1
    return pd.DataFrame({"Ann. mean return": mu, "CAGR": cagr, "Ann. volatility": vol, "Sharpe": (mu - rf) / vol})


def shrunk_cov(r):
    """Ledoit-Wolf shrinkage covariance, annualised."""
    return pd.DataFrame(LedoitWolf().fit(r.values).covariance_ * TD, index=r.columns, columns=r.columns)


# ---------------------------------------------------------------- optimisation
def port_perf(w, mu, cov, rf=0.0):
    ret = w @ mu
    vol = np.sqrt(w @ cov @ w)
    return ret, vol, (ret - rf) / vol


def _solve(obj, n, cap, extra=()):
    cons = [{"type": "eq", "fun": lambda w: w.sum() - 1}, *extra]
    res = minimize(obj, np.full(n, 1 / n), method="SLSQP", bounds=[(0, cap)] * n, constraints=cons, options={"maxiter": 500, "ftol": 1e-12})
    if not res.success:
        raise RuntimeError(res.message)
    return res.x


def min_variance(cov, cap=1.0):
    C = np.asarray(cov)
    return _solve(lambda w: w @ C @ w, len(C), cap)


def max_sharpe(mu, cov, rf, cap=1.0):
    m, C = np.asarray(mu), np.asarray(cov)
    return _solve(lambda w: -(w @ m - rf) / np.sqrt(w @ C @ w), len(C), cap)


def target_return(mu, cov, target, cap=1.0):
    m, C = np.asarray(mu), np.asarray(cov)
    return _solve(lambda w: w @ C @ w, len(C), cap, extra=({"type": "eq", "fun": lambda w: w @ m - target},))


def risk_parity(cov):
    """Equal risk contribution (long-only). Solves the convex problem
    min ½·yᵀΣy − (1/n)·Σ ln yᵢ  (y > 0); at the optimum yᵢ(Σy)ᵢ = 1/n for every i,
    so every asset contributes equally to risk. Weights w = y / Σy."""
    C = np.asarray(cov); n = len(C); b = np.full(n, 1 / n)
    y0 = 1 / np.sqrt(np.diag(C))
    res = minimize(lambda y: 0.5 * y @ C @ y - b @ np.log(y), y0, jac=lambda y: C @ y - b / y,
                   method="L-BFGS-B", bounds=[(1e-10, None)] * n, options={"maxiter": 2000, "gtol": 1e-12})
    w = res.x / res.x.sum()
    rc = w * (C @ w); assert np.allclose(rc / rc.sum(), b, atol=1e-4), "risk parity did not converge"
    return w


def efficient_frontier(mu, cov, cap, n_pts=40):
    lo = port_perf(min_variance(cov, cap), np.asarray(mu), np.asarray(cov))[0]
    hi = np.sort(np.asarray(mu))[::-1]
    k = int(np.ceil(1 / cap)); hi = hi[:k - 1].sum() * cap + hi[k - 1] * (1 - cap * (k - 1))  # max reachable return under cap
    pts = []
    for t in np.linspace(lo, hi * 0.999, n_pts):
        w = target_return(mu, cov, t, cap)
        r_, v_, _ = port_perf(w, np.asarray(mu), np.asarray(cov))
        pts.append((v_, r_))
    return pd.DataFrame(pts, columns=["vol", "ret"])


def random_portfolios(mu, cov, rf, n=10_000, seed=42):
    rng = np.random.default_rng(seed)
    W = rng.dirichlet(np.ones(len(mu)), n)
    m, C = np.asarray(mu), np.asarray(cov)
    ret = W @ m
    vol = np.sqrt(np.einsum("ij,jk,ik->i", W, C, W))
    return pd.DataFrame({"ret": ret, "vol": vol, "sharpe": (ret - rf) / vol})


# ---------------------------------------------------------------- CAPM
def capm(r_assets, r_mkt, rf):
    """OLS of daily excess returns on market excess returns."""
    rf_d = rf / TD
    x = r_mkt - rf_d
    X = np.column_stack([np.ones(len(x)), x])
    out = {}
    for col in r_assets:
        y = r_assets[col] - rf_d
        b, *_ = np.linalg.lstsq(X, y, rcond=None)
        resid = y - X @ b
        s2 = resid @ resid / (len(y) - 2)
        se = np.sqrt(np.diag(s2 * np.linalg.inv(X.T @ X)))
        r2 = 1 - resid @ resid / ((y - y.mean()) @ (y - y.mean()))
        out[col] = {"Beta": b[1], "Alpha (ann.)": b[0] * TD, "Alpha t-stat": b[0] / se[0], "R²": r2, "Idiosyncratic vol": np.sqrt(s2 * TD)}
    return pd.DataFrame(out).T


# ---------------------------------------------------------------- risk
def var_table(r_port, conf=(0.95, 0.99), value=1e7, sims=100_000, r_assets=None, w=None, seed=7):
    rows = {}
    mu, sd = r_port.mean(), r_port.std()
    rng = np.random.default_rng(seed)
    if r_assets is not None:
        mc = rng.multivariate_normal(r_assets.mean().values, r_assets.cov().values, sims) @ w
    for c in conf:
        a = 1 - c
        h_var = -np.quantile(r_port, a); h_cvar = -r_port[r_port <= -h_var].mean()
        p_var = -(mu + sd * norm.ppf(a)); p_cvar = -(mu - sd * norm.pdf(norm.ppf(a)) / a)
        rows[f"Historical {c:.0%}"] = (h_var, h_cvar)
        rows[f"Parametric (normal) {c:.0%}"] = (p_var, p_cvar)
        if r_assets is not None:
            m_var = -np.quantile(mc, a); rows[f"Monte Carlo {c:.0%}"] = (m_var, -mc[mc <= -m_var].mean())
    t = pd.DataFrame(rows, index=["VaR", "CVaR"]).T
    t["VaR (₹ on ₹1 cr)"] = t["VaR"] * value; t["CVaR (₹ on ₹1 cr)"] = t["CVaR"] * value
    return t


def kupiec(exceptions, n, p):
    """Kupiec proportion-of-failures likelihood-ratio test."""
    x = exceptions; phat = x / n
    lr = -2 * ((n - x) * np.log(1 - p) + x * np.log(p) - (n - x) * np.log(1 - phat) - x * np.log(phat))
    return lr, 1 - chi2.cdf(lr, 1)


def drawdown(wealth):
    return wealth / wealth.cummax() - 1


# ---------------------------------------------------------------- backtest
def backtest(r, strategies, lookback=504, rebalance=63, cost_bps=10, cap=0.25, rf=0.0):
    """Walk-forward: at each rebalance date, estimate on the trailing window only, then hold
    (weights drift with prices) until the next rebalance. Cost = cost_bps × one-way turnover."""
    n = r.shape[1]; dates = r.index
    out, weights_hist, turnover = {}, {}, {}
    for name, fn in strategies.items():
        w = np.zeros(n); rets = []; wh = {}; to = []
        for i in range(lookback, len(r)):
            if (i - lookback) % rebalance == 0:
                win = r.iloc[i - lookback:i]
                new = fn(win)
                t = np.abs(new - w).sum() / 2 if w.sum() > 0 else 1.0
                to.append(t); cost = t * cost_bps / 1e4
                w = new; wh[dates[i]] = new
            else:
                cost = 0.0
            day = r.iloc[i].values
            pr = w @ day
            rets.append(pr - cost)
            w = w * (1 + day) / (1 + pr)
        out[name] = pd.Series(rets, index=dates[lookback:])
        weights_hist[name] = pd.DataFrame(wh, index=r.columns).T
        turnover[name] = np.mean(to[1:]) if len(to) > 1 else np.nan
    return pd.DataFrame(out), weights_hist, turnover


def perf_table(rets, rf, bench=None, turnover=None):
    rows = {}
    for col in rets:
        r = rets[col]; w = (1 + r).cumprod()
        yrs = len(r) / TD; cagr = w.iloc[-1] ** (1 / yrs) - 1
        vol = r.std() * np.sqrt(TD); down = r[r < 0].std() * np.sqrt(TD)
        mdd = drawdown(w).min()
        row = {"CAGR": cagr, "Volatility": vol, "Sharpe": (r.mean() * TD - rf) / vol, "Sortino": (r.mean() * TD - rf) / down,
               "Max drawdown": mdd, "Calmar": cagr / abs(mdd)}
        if bench is not None:
            row["Beta vs NIFTY"] = np.cov(r, bench)[0, 1] / bench.var()
            active = r - bench; row["Information ratio"] = active.mean() * TD / (active.std() * np.sqrt(TD)) if active.std() > 0 else np.nan
        if turnover is not None:
            row["Avg turnover / rebalance"] = turnover.get(col, np.nan)
        rows[col] = row
    return pd.DataFrame(rows).T
