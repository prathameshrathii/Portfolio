# Downloads 7 years of daily prices for the portfolio project and saves prices.csv
# Run in Google Colab (colab.research.google.com) or any Python with internet.
# In Colab/Jupyter first run:  !pip install yfinance

import yfinance as yf

tickers = [
    "RELIANCE.NS", "HDFCBANK.NS", "ICICIBANK.NS", "INFY.NS", "TCS.NS", "ITC.NS",
    "HINDUNILVR.NS", "LT.NS", "SUNPHARMA.NS", "BHARTIARTL.NS", "MARUTI.NS", "TITAN.NS",
    "GOLDBEES.NS",   # gold ETF – diversifier
    "^NSEI",         # NIFTY 50 benchmark
]

data = yf.download(tickers, start="2019-11-01", end="2026-11-21", auto_adjust=True, progress=False)["Close"]
data.to_csv("prices.csv")
print(data.shape)
print(data.tail())
print("Missing values per ticker:\n", data.isna().sum())

# In Colab: download the file
try:
    from google.colab import files
    files.download("prices.csv")
except ImportError:
    print("Saved prices.csv in the current folder")
